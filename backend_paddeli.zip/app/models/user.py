import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, CheckConstraint, text, func, Uuid
from sqlalchemy.orm import relationship
from app.core.database import Base


class User(Base):
    __tablename__ = "users"
    __table_args__ = (
        CheckConstraint("role IN ('customer', 'professional', 'admin', 'super_admin')", name="users_role_check"),
    )

    id = Column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    phone = Column(String(15), unique=True, nullable=False, index=True)
    full_name = Column(String(120), nullable=False)
    role = Column(String(20), nullable=False, index=True)
    status = Column(String(20), nullable=False, server_default="active", default="active", index=True)
    password_hash = Column(String(255), nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=False, server_default=func.now(), default=lambda: datetime.now(timezone.utc), index=True)

    # Relationships
    customer_profile = relationship("CustomerProfile", back_populates="user", uselist=False, cascade="all, delete-orphan")
    professional_profile = relationship("ProfessionalProfile", back_populates="user", uselist=False, cascade="all, delete-orphan")
    customer_bookings = relationship("Booking", foreign_keys="Booking.customer_id", back_populates="customer")
    professional_bookings = relationship("Booking", foreign_keys="Booking.professional_id", back_populates="professional")
    reported_incidents = relationship("Incident", back_populates="reporter")

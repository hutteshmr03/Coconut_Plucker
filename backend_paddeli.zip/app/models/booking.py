import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, Text, Integer, Boolean, Numeric, DateTime, CheckConstraint, ForeignKey, text, func, Uuid
from sqlalchemy.orm import relationship
from app.core.database import Base


class Booking(Base):
    __tablename__ = "bookings"
    __table_args__ = (
        CheckConstraint(
            "height_category IS NULL OR height_category IN ('low', 'medium', 'high')",
            name="bookings_height_category_check"
        ),
    )

    id = Column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    booking_number = Column(String(40), nullable=True, index=True)
    customer_id = Column(Uuid(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    professional_id = Column(Uuid(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    service_id = Column(Uuid(as_uuid=True), ForeignKey("services.id", ondelete="SET NULL"), nullable=True, index=True)
    service_name = Column(String(160), nullable=True)
    tree_count = Column(Integer, nullable=True, default=1)
    height_category = Column(String(20), nullable=True)
    taluka = Column(String(80), nullable=True)
    address = Column(Text, nullable=True)
    booking_type = Column(String(20), nullable=True, default="standard")
    call_confirmed = Column(Boolean, nullable=True, default=True)
    hazard_notes = Column(Text, nullable=True)
    tree_photo = Column(Text, nullable=True)
    scheduled_at = Column(DateTime(timezone=True), nullable=False, index=True)
    status = Column(String(20), nullable=False, server_default="requested", default="requested", index=True)
    quote_amount = Column(Numeric(8, 2), nullable=True)
    completed_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=False, server_default=func.now(), default=lambda: datetime.now(timezone.utc), index=True)

    # Relationships
    customer = relationship("User", foreign_keys=[customer_id], back_populates="customer_bookings")
    professional = relationship("User", foreign_keys=[professional_id], back_populates="professional_bookings")
    service = relationship("Service", back_populates="bookings")
    payment = relationship("Payment", back_populates="booking", uselist=False, cascade="all, delete-orphan")
    review = relationship("Review", back_populates="booking", uselist=False, cascade="all, delete-orphan")
    incidents = relationship("Incident", back_populates="booking", cascade="all, delete-orphan")
